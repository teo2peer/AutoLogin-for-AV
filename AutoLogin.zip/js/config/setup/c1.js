$(document).ready(function () {
    $("#config2").click(function () {
        window.location.href = "/pages/setup/config2.html";
    });
    
});

